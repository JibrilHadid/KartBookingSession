DROP TABLE IF EXISTS booking.tblCoachInfo;
DROP TABLE IF EXISTS booking.tblKartManufacturer;
DROP TABLE IF EXISTS booking.tblKarts;
DROP TABLE IF EXISTS location.tblCoachLocation;
DROP TABLE IF EXISTS booking.tblCoach;
DROP TABLE IF EXISTS location.tblTracks;
DROP TABLE IF EXISTS location.tblSuburb;
DROP TABLE IF EXISTS location.tblCity;

DROP SCHEMA IF EXISTS booking;
DROP SCHEMA IF EXISTS location;