SELECT avg(kartPrice) as avgKartPrice 
FROM booking.tblKarts
ORDER BY avgKartPrice;