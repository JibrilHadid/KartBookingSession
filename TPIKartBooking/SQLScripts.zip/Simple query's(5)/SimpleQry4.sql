SELECT * 
FROM location.tblSuburb
ORDER BY suburbID asc;