SELECT * 
FROM Booking.tblKartManufacturer 
ORDER BY manufacturerID asc;