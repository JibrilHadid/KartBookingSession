SELECT * 
FROM location.tblTracks
ORDER BY trackID asc;