SELECT * 
FROM location.tblCity
ORDER BY cityID asc;