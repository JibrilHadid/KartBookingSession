SELECT * 
FROM booking.tblKarts
ORDER BY kartID asc;